from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    fio = models.CharField(max_length=55)
    number = models.CharField(max_length=12)
    email = models.EmailField()
    login = models.CharField(unique=True, max_length=50)

    USERNAME_FIELD = 'login'
    REQUIRED_FIELDS = ['fio', 'number', 'email', 'username']


class Statement(models.Model):
    desc = models.CharField(max_length=255)
    number_car = models.CharField(max_length=20)
    status = models.CharField(default="Новое", max_length=30)