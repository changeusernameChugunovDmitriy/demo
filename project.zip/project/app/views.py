from django.shortcuts import render
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED, HTTP_422_UNPROCESSABLE_ENTITY, HTTP_401_UNAUTHORIZED, HTTP_200_OK

from .models import User
from .serializers import RegistrationSerializers, LoginSerializers, StatementSerializers, StatementAdminSerializers


@api_view(['POST'])
def registration_view(request):
    serializers = RegistrationSerializers(data=request.data)
    if serializers.is_valid():
        user = serializers.save()
        token = Token.objects.create(user=user)
        return Response({'data': {'user_token': token.key}}, status=HTTP_201_CREATED)
    return Response({'error': {'code': 422, 'message': 'Validation error', 'errors': serializers.errors}},
                    status=HTTP_422_UNPROCESSABLE_ENTITY)


@api_view(['POST'])
def login_view(request):
    serializers = LoginSerializers(data=request.data)
    if serializers.is_valid():
        try:
            user = User.objects.get(login=serializers.validated_data['login'])
        except:
            return Response({"error": {"code": 401, "message": "Authentication failed"}}, status=HTTP_401_UNAUTHORIZED)
        token, _ = Token.objects.get_or_create(user=user)
        return Response({'data': {'user_token': token.key}}, status=HTTP_200_OK)
    return Response({'error': {'code': 422, 'message': 'Validation error', 'errors': serializers.errors}},
                    status=HTTP_422_UNPROCESSABLE_ENTITY)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_form(request):
    serializers = StatementSerializers(data=request.data)
    if serializers.is_valid():
        form = serializers.save()
        return Response({"data": {"message": "Form is create"}}, status=HTTP_201_CREATED)
    return Response({'error': {'code': 422, 'message': 'Validation error', 'errors': serializers.errors}},
                    status=HTTP_422_UNPROCESSABLE_ENTITY)


@api_view(['GET'])
@permission_classes([IsAdminUser])
def get_form_admin(request):
    form = StatementSerializers.objects.all()
    serializers = StatementAdminSerializers(form)
    if serializers.is_valid():
        return Response({'data': serializers.data})
    return Response({'error': {'code': 422, 'message': 'Validation error', 'errors': serializers.errors}},
                    status=HTTP_422_UNPROCESSABLE_ENTITY)