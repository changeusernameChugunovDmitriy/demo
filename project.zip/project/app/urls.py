from django.urls import path

from .views import login_view, registration_view, create_form, get_form_admin

urlpatterns = [
    path('login', login_view),
    path('registration', registration_view),
    path('form', create_form),
    path('admin/form', get_form_admin),
]