from rest_framework import serializers, request

from .models import User, Statement


class RegistrationSerializers(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['fio', 'number', 'email', 'login', 'password']

    def save(self, **kwargs):
        user = User(email=self.validated_data['email'],
                    fio=self.validated_data['fio'],
                    number=self.validated_data['number'],
                    username=self.validated_data['email'],
                    login=self.validated_data['login'])
        user.set_password(self.validated_data['password'])
        user.save()
        return user


class LoginSerializers(serializers.Serializer):
    login = serializers.CharField()
    password = serializers.CharField()


class StatementSerializers(serializers.ModelSerializer):
    class Meta:
        model = Statement
        fields = '__all__'


class StatementAdminSerializers(serializers.ModelSerializer):
    form = StatementSerializers()
    user = request.user

    class Meta:
        model = Statement
        fields = ['form', 'user']
